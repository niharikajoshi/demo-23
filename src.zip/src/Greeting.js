import React, { Component } from 'react'
import PropTypes from 'prop-types';

export class Greeting extends Component {
  render() {
    return (
        <>
        <div>Greeting</div>
        {/* <div>Sum: {this.props.num1 + this.props.num2}</div> */}
        {this.props.num1.map((i) => (
            <div key={i.id}>{i.id}.{i.name}</div>
        ))}
        {this.props.num2}
        </>
      
    )
  }
}

Greeting.propTypes = {
    num1: PropTypes.array,
    num2: PropTypes.number
}
export default Greeting

Greeting.defaultProps = {
    num1: [{id:1, name: "Surojit"}, 
    {id:2, name: "Ashray"},
    {id:3, name: "Keyul"}
  ],
    num2: 10
}