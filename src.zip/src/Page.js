import React from "react";
import { MyContext } from "./MyContext";
import { useContext } from "react";
import Page1, { TimeContext } from "./Page1";

export default function Page() {
  // method 1
  const theme = useContext(MyContext);
//   const obj = useContext(TimeContext);
  return (
    <>
      <div>{theme}</div>
      {/* <div>{obj}</div> */}
      <Page1 />
    </>
  );

  //method2
  //   return (
  //     <MyContext.Consumer>{(value) => <div>{value}</div>}</MyContext.Consumer>
  //   );
}
