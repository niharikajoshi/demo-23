import React, { Component } from 'react'

export class Top extends Component {

    constructor(){
        super();
        this.num = 10;
    }
  render() {
    const myElement = <>
    <div>I am top class</div>
    <div>{this.num}</div>
    </>
    return (
        <>
        {myElement}
        </>
        
      
    )
  }
}

export default Top;

//comparing class and function
// function Top(){
//     return (
//         <p>I am Top</p>
//     )
// }

// const Top = () => {
//     return <p>I am Top</p>
// }