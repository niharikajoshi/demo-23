// import logo from './logo.svg';
// import './App.css';

import React, { createContext, useState } from "react";
import Top from "./top";
import Header from "./Header";
import Center from "./Center";
import Footer from "./Footer";
import Counter from "./Counter";
import Condition from "./Condition";
import Countdown from "./Countdown";
import Search from "./Search";
import Lifecycle from "./Lifecycle";
import MapDemo from "./MapDemo";
import FlowerListDemo from "./FlowerListDemo";
import EmployeeList from "./EmployeeList";
import Clock from "./Clock";
import { MyContext } from "./MyContext";
import Page from "./Page";
import Greeting from "./Greeting";
import Todoparent from "./Todoparent";
import VehicleList from "./VehicleList";
import {BrowserRouter, Route, Routes, Link} from 'react-router-dom';
import AddVehicle from "./AddVehicle";
import UpdateVehicle from "./UpdateVehicle";

export const BillContext = createContext();


function App() {

  const [compName] = useState(1);
  const [username, setUserName] = useState('Surojit')
  return (
    <>
    {/* <Header num1={15}/> */}
    {/* <Condition/> */}
    {/* <Counter/> */}
    {/* <Countdown/> */}
    {/* <Search/> */}
    {/* <Lifecycle/> */}
    {/* <MapDemo/> */}
    {/* <FlowerListDemo/> */}
    {/* <EmployeeList/> */}
    {/* <Clock/> */}
    {/* <BillContext.Provider value={compName}>
    <MyContext.Provider value={username}>
      <Page/>
    </MyContext.Provider>
    </BillContext.Provider> */}
    {/* <Greeting num2={null}/> */}
    {/* <Todoparent/> */}
    <BrowserRouter>
    <div>
      <Link to = "/add">Add Vehicle</Link>
      <Link to = "/update">Update Vehicle</Link>
      <Link to = "/">Home</Link>
    </div>
    <Routes>
      <Route path = "/" element={<VehicleList/>}></Route>
      <Route path = "/add" element={<AddVehicle/>}></Route>
      <Route path = "/update" element={<UpdateVehicle/>}></Route>
    </Routes>
    </BrowserRouter>
    
    
    </>
    
  );
}

export default App;
