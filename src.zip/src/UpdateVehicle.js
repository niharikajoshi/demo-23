import React from 'react'

export default function UpdateVehicle() {
  return (
    <div>UpdateVehicle</div>
  )
}
