import React, { Component } from 'react'

export class ChildLife extends Component {

    constructor(props){
        super(props);
        this.state = {
            season: this.props.season,
            num: 0
        }
        console.log("childlife: constructor called");
    }

    componentDidMount(){
        console.log("childlife: componentDidMount");
        this.setState({ season: "Summer"})
    }

    shouldComponentUpdate(nextProps, nextState) {
        let flag = true;
        if(nextState.num % 2 == 0){
            flag = true;
        } else{
            flag = false;
        }

        return flag;
    }

    static getDerivedStateFromProps(props, state) {
        console.log("childlife: getDerivedStateFromProps called");
    } 

  render() {
    console.log('childlife: render called');
    return (
        <>
        <div>ChildLife</div>
        <div>{this.state.season}</div>
        {this.state.num}
        <button onClick={() => {
            this.setState({num: this.state.num + 1})
        }}> Next Even Number </button>
        </>
      
    )
  }
}

export default ChildLife