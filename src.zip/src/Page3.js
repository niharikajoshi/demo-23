import React, { useContext } from 'react'
import { BillContext } from './App';

export default function Page3() {
    const cname = useContext(BillContext);
  return (
    <>
    <div>Page3</div>
    {cname}
    </>
    
  )
}
