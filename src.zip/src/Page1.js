import React, { createContext } from 'react'
import Page2 from './Page2'

export const TimeContext = createContext();

export default function Page1() {

  return (
    <>
    <div>Page1</div>
    <TimeContext.Provider value={new Date()}>
    <Page2/>
    </TimeContext.Provider>
    
    </>
    
  )
}
