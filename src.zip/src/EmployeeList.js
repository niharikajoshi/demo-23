import React, { useEffect, useState } from "react";

export default function EmployeeList() {
  const [empList, funcEmpList] = useState([]);

  useEffect(() => {
    funcEmpList([
      { pid: 1, name: "Surojit", sal: 8.5 },
      { pid: 2, name: "Ashray", sal: 80.5 },
      { pid: 3, name: "Jatin", sal: 8.5 },
    ]);
  }, []);

  return (
    <>
      <div>EmployeeList</div>
      <table border={"1px solid black"}>
        <thead>
          <tr><th>Name</th><th>Salary</th></tr>
        </thead>
        <tbody>
          {empList.map((emp) => (
            <tr key={emp.pid}>
              <td>{emp.name}</td><td>{emp.sal}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
