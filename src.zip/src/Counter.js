import React, { Component } from "react";

export class Counter extends Component {
  constructor() {
    super();
    this.state = {
      count: 0,
      msg: "",
    };
  }

  incrementCount(){
    this.setState({
        count: this.state.count + 1,
    });
  }
  render() {
    return (
      <>
      <div className="container">
      <button className="btn-secondary"
          onClick={this.incrementCount.bind(this)}
        >
          Increment
        </button>

        {this.state.count}

        <button className="btn-danger"
          onClick={() => {
            this.setState({
              count: this.state.count - 1,
            });
          }}
        >
          Decrement
        </button>
      </div>
        
      </>
    );
  }
}

export default Counter;
