import React from 'react'

export default function Footer(props) {
    // props.time = '11111';
  return (
    // <div>This is Footer {props.msg} {props.time} {props.num1}</div>
    <>
      <div>This is Footer</div>
    </>
  )
}
