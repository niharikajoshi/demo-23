import React from 'react'

export default function AddVehicle() {
  return (
    <div>AddVehicle</div>
  )
}
