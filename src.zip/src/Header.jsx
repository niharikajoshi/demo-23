import React from "react";
import Center from "./Center";

// function getMsg(){
//   alert('Function called');
// }

export default function Header(props) {
  return (
    <>
      {/* <div>This is Header {props.num1}</div>
      <Center name="Rahul" {...props} />
      <button
        onClick={getMsg}
      >
        OK
      </button> */}
      <div>This is Header</div>
    </>
  );
}
