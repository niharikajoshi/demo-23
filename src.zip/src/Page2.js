import React from 'react'
import Page3 from './Page3'
import { BillContext } from './App';
import { useContext } from 'react';

export default function Page2() {
    const cname = useContext(BillContext);
  return (
    <BillContext.Provider value={cname+1}>
<>
    <div>Page2</div>
    
    <Page3/>
    </>
    </BillContext.Provider>
    
    
  )
}
