import React, { Component } from 'react'

export class FlowerListDemo extends Component {
    constructor(){
        super();
        this.fruits = ['Apple', 'Mango'];
    }
  render() {
    return (
        <>
        <div>FlowerListDemo</div>
        {this.fruits.map((fruit, i) => <div key = {fruit}>{fruit}</div>)}
        </>
      
    )
  }
}

export default FlowerListDemo