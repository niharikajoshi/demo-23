import React from 'react'
import Header from './Header';
import Footer from './Footer';

export default function Condition() {

    const myElement = (
        // (12 == 2) ? <Header/> : <Footer/>
        (12 > 2) && <Header/>
    );
  return (
    <>
    {myElement}
    </>
  )
}
