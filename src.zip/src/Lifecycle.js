import React, { Component } from "react";
import ChildLife from "./ChildLife";

export default class Lifecycle extends Component {

    constructor(){
        super();
        this.state = {
            season : "Rainy",
            fruits: []
        }
        console.log("lifecycle: constructor called");
    }

    // deprecated
    // componentWillMount(){
    //     console.log("Childlife component will Mount");
    // }

    componentDidMount(){
        // console.log("lifecycle: componentDidMount");
        console.log(JSON.stringify(this.state.fruits));
        
        

    }

    static getDerivedStateFromProps(props, state) {
        console.log("lifecycle: getDerivedStateFromProps called");
    }

  render() {
    // console.log("lifecycle: render called");
    
    return (
      <>
        <div>Lifecycle</div>
        <ChildLife season = {this.state.season}/>
        {this.state.fruits.map((fruit) => <div key="fruit">{fruit}</div>)}
      </>
    );
  }
}
