import React, { Component, useEffect, useState } from "react";

// export class Clock extends Component {
//   constructor() {
//     super();
//     this.state = { date: new Date() };
//   }

//   componentDidMount() {
//     this.timerID = setInterval(() => this.tick(), 1000);
//   }

//   componentWillUnmount() {
//     // clearInterval(this.timerID);
//   }

//   tick() {
//     this.setState({
//       date: new Date(),
//     });
//   }

//   render() {
//     return (
//       <div>
//         <h1>Hello, world!</h1>
//         <h2>It is {this.state.date.toLocaleTimeString()}.</h2>
//       </div>
//     );
//   }
// }

// export default Clock;

export default function Clock() {
  const [date, changeDate] = useState(new Date());

  useEffect(() => {
    setInterval(() => changeDate(new Date()), 1000);
  })
  
  return (
    <div>
    <h1>Hello, world!</h1>
    <h2>It is {date.toLocaleTimeString()}.</h2>
  </div>
  );
}
