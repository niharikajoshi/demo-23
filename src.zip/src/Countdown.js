import React, { useState } from "react";

export default function Countdown() {
  const [count, setCount] = useState(10);
  const [msg, setMsg] = useState("Hello");

  function decrease() {
    setCount(count - 1);
    setMsg("Bye");
  }

  let increment = () => {
    setCount(count + 1);
  };

  return (
    <>
      <button className="btn-primary" onClick={increment}>
        +
      </button>
      {count}
      <button className="btn-primary" onClick={decrease}>
        -
      </button>
      <br />
      {msg}
    </>
  );
}
