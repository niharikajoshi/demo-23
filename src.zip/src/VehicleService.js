import axios from 'axios';

const apiUrl = "http://localhost:8080/vehicle";

class VehicleService{
    getVehicleList(){
        return axios.get(apiUrl+"/get");
    }
}

export default new VehicleService();