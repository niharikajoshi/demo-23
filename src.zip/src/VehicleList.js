import React, { Component } from 'react'
import VehicleService from './VehicleService'

export class VehicleList extends Component {
  
  constructor(){
    super();
    this.state = {
        vehicles: []
    }
  }

  componentDidMount(){
    VehicleService.getVehicleList().then(
        (obj) => {
            this.setState({vehicles: obj.data})
        }
    );
  }
  
    render() {
    return (
        <>
        <div>VehicleList</div>
        <table>
            <thead>
                <tr>
                    <th>VehicleID</th>
                    <th>Model</th>
                    <th>Company</th>
                </tr>
            </thead>
            <tbody>
                {this.state.vehicles.map(
                    (v) => (<tr key={v.vehicleid}>
                        <td>{v.vehicleid}</td>
                        <td>{v.modelno}</td>
                        <td>{v.company}</td>
                    </tr>)
                )}
            </tbody>
        </table>
        
        </>
      
    )
  }
}

export default VehicleList