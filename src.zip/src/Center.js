import React, { Component } from 'react'
import Footer from './Footer'

export default class Center extends Component {
  render() {
    return (
        <>
        <div>This is Center {this.props.num1}</div>
        <Footer msg="BreakTime" time="1:30" {...this.props}/>
        </>
      
    )
  }
}
