import React, { useEffect } from 'react'

export default function MapDemo() {

    const [fruits, setFruits] = React.useState([]);

    useEffect(() => {
        setFruits(['Apple', 'Mango', 'Banana', 'Grapes', 'Watermelon'])
        console.log('Bro');
    }, [])
    
  return (
    
    <>
    {console.log("hi")}
    <div>MapDemo</div>
    {fruits.map((fruit, index) => <div key={index}>{index + 1}{fruit}</div>
    )}
    </> 

  )
}
